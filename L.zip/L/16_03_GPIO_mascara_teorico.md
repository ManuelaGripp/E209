# Exercicio Teorico

1. VOL = 0.9V 
pag 366  
32 - Electrical Characteristics  
32.2 - Common DC Characteristic

VOH = 4.2V 
pag 366 
32 - Electrical Characteristics
32.2 - Common DC Characteristic

2. Operating Voltage = 1.8V - 5.5V
pag 365
32 - Electrical Characteristics
32.1 - Absolute Maximum Ratings

3. Corrente Maxima = 40mA 
pag 365
32 - Electrical Characteristics
32.1 - Absolute Maximum Ratings

4. VIL3 = 0.3*Vcc[V]
pag 365
32 - Electrical Characteristics
32.2 - Common DC Characteristics

VIH3 = Vcc + 0.5 [V]
pag 366 
32 - Electrical Characteristics
32.2 - Common DC Characteristic